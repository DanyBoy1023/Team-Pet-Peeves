# Pet Peeves: Dodge the Coughers (Godot 4)

Open this folder through the Godot 4 project manager (Import, select `project.godot`). Press F5 to run.

Controls: arrow keys or WASD to move. Space or the Start button begins a round.

## How it plays

The street scrolls downward as you walk up it. Sick pedestrians walk down from the top of the screen.
Touch one and you catch it. Each second survived adds one point. The street scrolls faster and more
people spawn as your score climbs. Every 25 points the player strikes a victory pose.

## Art

All sprites are the supplied cut-out photos, resized into `art/`. They are exported at 2x display size
and the nodes use scale 0.5.

- `player_*`: up, down, left, right walk cycles, idle, victory, and four hit reactions (one is picked at random).
  `player_down_2` is a mirror of `player_down_1`.
- `e1_*`: the orange-jacket cougher. Walks, then plays wind-up, cough, and splatter every couple of seconds.
- `e2_*`, `e3_walk`: walkers with one pose each. `e2_away` walks the same way as the player, so it moves slower than the street.
- `e4_*`: the kid. Walks, then stops to barf now and then.
- `street.jpg`: the street photo, cropped to remove the cut-off crosswalk and cross-faded so it loops.
- `player_lookback.png` and `player_faceleft.png` are exported but not used yet.

## Tuning

- Difficulty: constants at the top of `main.gd`.
- Pedestrian types, weights, and hitboxes: the `TYPES` table at the top of `mob.gd`.
- Player speed: `speed` in `player.gd`.
